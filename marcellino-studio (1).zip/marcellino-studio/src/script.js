const VAULT_DATA = {
    owner: {
        firstName: "FRANS",
        lastName: "MARCELLINO",
        fullName: "Frans Marcellino",
        email: "fransmarselinosroyer@gmail.com",
        badge: "[ Sovereign Repository v8.0 ]"
    },
    content: {
        heroTitle: "Architecting Digital Sovereignty.",
        heroDesc: "Industrial-grade software assets designed for those who demand absolute performance and uncompromising aesthetic perfection.",
        footer: "© 2026 FRANS MARCELLINO — ALL RIGHTS RESERVED"
    },
    products: [
        { name: "Titan Core", price: "$1,290", desc: "Enterprise SaaS Framework.", img: "https://images.unsplash.com/photo-1614850523296-d8c1af93d400" },
        { name: "Quantum UI", price: "$750", desc: "Kinetic React Components.", img: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0" },
        { name: "SecureAuth X", price: "$490", desc: "Zero-Knowledge Auth Suite.", img: "https://images.unsplash.com/photo-1550745165-9bc0b252726f" },
        { name: "Nebula AI", price: "$2,999", desc: "Neural Integration Engine.", img: "https://images.unsplash.com/photo-1677442136019-21780ecad995" },
        { name: "Apex CMS", price: "$1,800", desc: "Headless Content Engine.", img: "https://images.unsplash.com/photo-1451187580459-43490279c0fa" },
        { name: "Zenith ERP", price: "$4,500", desc: "Global Logistics Logic.", img: "https://images.unsplash.com/photo-1460925895917-afdab827c52f" },
        { name: "Vortex DB", price: "$980", desc: "Real-time Vector Database.", img: "https://images.unsplash.com/photo-1558494949-ef010cbdcc51" },
        { name: "Cipher Mesh", price: "$1,100", desc: "P2P Encryption Layer.", img: "https://images.unsplash.com/photo-1563986768609-322da13575f3" }
    ],
    menu: [
        { label: "Home", id: "home" },
        { label: "Vault", id: "market" },
        { label: "About", id: "about" },
        { label: "Contact", id: "contact" }
    ]
};

// --- NAVIGATION ENGINE ---
function navigateTo(id, pushState = true) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const targetPage = document.getElementById(id);
    if(targetPage) targetPage.classList.add('active');
    
    window.scrollTo({top: 0, behavior: 'smooth'});
    toggleMenu(true);

    if (pushState) {
        history.pushState({ pageId: id }, null, `#${id}`);
    }
}

window.onpopstate = function(event) {
    if (event.state && event.state.pageId) {
        navigateTo(event.state.pageId, false);
    } else {
        navigateTo('home', false);
    }
};

// --- THEME & CURSOR ---
function toggleTheme() {
    document.body.classList.toggle('light-mode');
    document.getElementById('theme-btn').innerText = document.body.classList.contains('light-mode') ? 'DARK MODE' : 'LIGHT MODE';
}

const cursor = document.getElementById('cursor');
document.addEventListener('mousemove', e => { 
    cursor.style.left = e.clientX + 'px'; 
    cursor.style.top = e.clientY + 'px'; 
});

// --- UI COMPONENTS ---
function typeWriter(text, i, cb) {
    const el = document.getElementById("hero-title");
    if (i < text.length) {
        el.innerHTML = text.substring(0, i+1) +'<span class="typewriter"></span>';
        setTimeout(() => typeWriter(text, i + 1, cb), 60);
    } else if (cb) setTimeout(cb, 500);
}

function renderProducts(data) {
    const grid = document.getElementById('main-grid');
    grid.innerHTML = '';
    data.forEach(p => {
        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = `
            <div class="price-tag">${p.price}</div>
            <img src="${p.img}?auto=format&fit=crop&w=800" class="card-img" loading="lazy">
            <h3 style="font-size:1.8rem; letter-spacing:-1px; margin-bottom:10px;">${p.name}</h3>
            <p style="color:var(--text-dim); margin-bottom:25px; font-weight:300;">${p.desc}</p>
            <button class="btn-premium" onclick="openModal('${p.name}', '${p.price}')">Acquire License</button>
        `;
        
        card.onmousemove = (e) => {
            const r = card.getBoundingClientRect();
            const x = (e.clientX - r.left) / r.width - 0.5;
            const y = (e.clientY - r.top) / r.height - 0.5;
            card.style.transform = `perspective(1000px) rotateY(${x * 10}deg) rotateX(${y * -10}deg) translateY(-10px)`;
        };
        card.onmouseleave = () => card.style.transform = `none`;
        grid.appendChild(card);
    });
}

// --- INITIALIZATION ---
function init() {
    document.getElementById('nav-logo').innerHTML = `${VAULT_DATA.owner.firstName} <span>${VAULT_DATA.owner.lastName}</span>`;
    document.getElementById('hero-badge').innerText = VAULT_DATA.owner.badge;
    document.getElementById('curated-by').innerHTML = `Curated Selection by <strong>${VAULT_DATA.owner.fullName}</strong>`;
    document.getElementById('footer-text').innerText = VAULT_DATA.content.footer;
    document.getElementById('hero-desc').innerText = VAULT_DATA.content.heroDesc;

    const dropdown = document.getElementById('social-links');
    const contactBox = document.getElementById('contact-methods');
    
    VAULT_DATA.menu.forEach(item => {
        dropdown.innerHTML += `<a href="javascript:void(0)" onclick="navigateTo('${item.id}')" style="padding:18px 25px; display:block; color:var(--text-dim); text-decoration:none; font-size:0.75rem; border-bottom:1px solid var(--border); transition:0.3s; font-weight:700;">${item.label.toUpperCase()}</a>`;
        contactBox.innerHTML += `<button class="btn-premium" style="background:var(--surface); color:var(--text-main); border:1px solid var(--border);" onclick="location.href='mailto:${VAULT_DATA.owner.email}'">${item.label} Channel</button>`;
    });

    const startPage = 'home';
    history.replaceState({ pageId: startPage }, null, `#${startPage}`);

    typeWriter(VAULT_DATA.content.heroTitle, 0, () => renderProducts(VAULT_DATA.products));
}

// --- SEARCH & MODAL ---
function toggleMenu(close = false) { 
    const d = document.getElementById('dropdown');
    if(d) d.style.display = (close || d.style.display === 'block') ? 'none' : 'block';
}

function handleSearch() {
    const q = document.getElementById('search-bar').value.toLowerCase();
    renderProducts(VAULT_DATA.products.filter(p => p.name.toLowerCase().includes(q) || p.desc.toLowerCase().includes(q)));
}

let curN = "", curP = "";
function openModal(n, p) { 
    curN = n; curP = p; 
    document.getElementById('target-name').innerText = n.toUpperCase(); 
    document.getElementById('target-price').innerText = p; 
    document.getElementById('modal').style.display = 'flex'; 
}
function closeModal() { document.getElementById('modal').style.display = 'none'; }

function confirmInquiry() {
    const name = document.getElementById('client-name').value;
    if(!name) return alert("Verification Required.");
    window.location.href = `mailto:${VAULT_DATA.owner.email}?subject=Acquisition: ${curN}&body=Client: ${name}\nRequested Asset: ${curN}\nInvestment: ${curP}`;
    closeModal();
}

window.onload = init;
window.onclick = (e) => { if (!e.target.closest('.menu-wrapper')) toggleMenu(true); }